class OpenidServiceTests extends GroovyTestCase {

    void testSomething() {

    }
}
